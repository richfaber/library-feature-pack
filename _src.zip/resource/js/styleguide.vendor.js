'use strict';

import { Prism } from '../../vendor/prism/prism';

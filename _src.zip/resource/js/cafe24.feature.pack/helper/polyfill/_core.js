"use stirct";

import classList from './classList';
import closest from './closest';
import dataset from './dataset';
import getComputedStyle from './getComputedStyle';
import promise from './promise';

export { classList, closest, dataset, getComputedStyle, promise };
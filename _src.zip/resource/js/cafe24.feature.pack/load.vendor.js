'use strict';

import jQuery from '../../../vendor/jquery/jquery-3.3.1';
import jQueryLite from '../../../vendor/jquery/jquery-3.3.1.slim';

export { jQuery, jQueryLite }
'use strict';

const helper = {

    putOnOffset(el, applyElement) {

        let relativeCoord = el.getBoundingClientRect(),
            data = {};

        data.width = relativeCoord.width;
        data.height = relativeCoord.height;

        data.t = relativeCoord.top;
        data.l = relativeCoord.left;
        data.r = data.l + data.width;
        data.b = data.t + data.height;

        data.ab= {};
        data.ab.t = relativeCoord.top + document.documentElement.scrollTop;
        data.ab.l = relativeCoord.left + document.documentElement.scrollLeft;
        data.ab.r = data.ab.l + data.width;
        data.ab.b = data.ab.t + data.height;
        data.ab.width = el.offsetWidth;
        data.ab.height = el.scrollHeight;

        if(applyElement == undefined || applyElement == true) {
            el.data = data;
        } else {
            return data;
        }


    }

};

export default helper;

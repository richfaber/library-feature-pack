'use strict';

import helper from './boardDrag.helper';

/**
 * 데이터 기록관리
 */
function dataManage(opts) {

    this['opts'] = opts;
    this['_coords'] = null;
    this['_currentCoords'] = null;
    this['_dropArea'] = [];
    this['_overlapItem'] = [];
    this['_overlapDropArea'] = false;
    this['_breakContextBoundry'] = false;
    this['_breakDropAreaBoundry'] = false;
    this['_gridCoord'] = null;

}

dataManage.prototype = {
    constructor: dataManage,

    recordNecessaryContext( context ) {

        helper.putOnOffset( context );

    },

    recordNecessaryDropArea( context, dropAreaOpt ) {

        // Drop 영역 좌표 기록
        for(let selector of dropAreaOpt.selector) {

            let dropEl = context.querySelectorAll( selector );
            dropEl.forEach( (dropAreaEl, idx) => {

                helper.putOnOffset( dropAreaEl );

                if(dropAreaOpt.grid) {
                    dropAreaEl.data.grid = this.createGridTable(dropAreaEl, dropAreaOpt);
                }

                this['_dropArea'].push( dropAreaEl );

            });
        }

    },

    /**
     * 아이템에 필요한 데이터 기록
     * @param {*} els - target element
     * @param {*} status - 
     */
    recordNecessaryItem( actionItems ) {

        let recordStyleRef = ['top', 'left', 'width', 'height', 'position'];

        function record(actionItem) {

            let elCssStyle = getComputedStyle(actionItem);

            actionItem.orgData = helper.putOnOffset(actionItem, false);
            recordStyleRef.forEach(item => {
                switch(item) {
                    case 'top':
                        actionItem.orgData[item] = actionItem.offsetTop;
                        break;
                    case 'left':
                        actionItem.orgData[item] = actionItem.offsetLeft;
                        break;
                    case 'width':
                        actionItem.orgData[item] = actionItem.offsetWidth;
                        break;
                    case 'height':
                        actionItem.orgData[item] = actionItem.offsetHeight;
                        break;
                    default:
                        actionItem.orgData[item] = elCssStyle[item] || 'static';
                }

            });

        }

        return new Promise((resolve, reject) => {

            if(actionItems instanceof Array) actionItems.forEach( actionItem => record(actionItem) );
            else record( actionItems );

            resolve();
        });

    },

    // 현재의 시작점 기록
    recordStartCoords(e, context, currentEl, actionEl) {

        currentEl.l = parseInt(currentEl.style.left, 10);
        currentEl.t = parseInt(currentEl.style.top, 10);

        this['_currentCoords'] = [];
        for (let el of actionEl) {

            // if (el === currentEl) continue;

            this['_currentCoords'].push({
                el: el,
                t: el.offsetTop,
                l: el.offsetLeft,
                b: el.offsetTop + el.clientHeight,
                r: el.offsetLeft + el.clientWidth,
            });

        }

    },
    //
    // // 이벤트 끝난 후 현재 위치 기록
    // recordEndCoords(e, context, currentEl, actionEl, overlapDropArea) {
    //
    //     for (let el of actionEl) {
    //
    //         // if (el === currentEl) continue;
    //         el.t = el.offsetTop;
    //         el.l = el.offsetLeft;
    //         el.b = el.t + el.clientHeight;
    //         el.r = el.l + el.clientWidth;
    //
    //     }
    //
    // },

    createGridTable(currentEl, dropAreaOpt) {

        let perWidth = currentEl.data.ab.width / dropAreaOpt.grid.unit.widthLength,
            perHeight = dropAreaOpt.grid.unit.height;

        let grid = [];
        grid['perWidth'] = perWidth;
        grid['perHeight'] = perHeight;

        for(let c = 0, d = dropAreaOpt.grid.unit.widthLength; c < d; c++) {
            grid[c] = [];

            for(let a = 0, b = 300; a<b; a++) {

                let gridSet = {
                    columnStart: perWidth * c,
                    rowStart: perHeight * a,
                    columnEnd: (perWidth * c) + perWidth,
                    rowEnd: (perHeight * a) + perHeight,
                    fill: false,
                    fillItem: null
                };

                grid[c][a] = gridSet
            }
        }

        return grid;

    },

    registerGridFill(overlapDropArea, holdItem) {

        // console.log(overlapDropArea);
        // if(!overlapDropArea) return;

        let columnStart = holdItem.data.grid['columnStart'],
            columnEnd = holdItem.data.grid['columnEnd'],
            rowStart = holdItem.data.grid['rowStart'],
            rowEnd = holdItem.data.grid['rowEnd'];

        for(let columnCount = columnStart, columnEndCount = columnEnd; columnCount < columnEndCount; columnCount++) {

            for(let rowCount = rowStart, rowEndCount = rowEnd; rowCount < rowEndCount; rowCount++) {
                overlapDropArea.data.grid[columnCount][rowCount].fill = true;
                overlapDropArea.data.grid[columnCount][rowCount].fillItem = holdItem;

            }

        }


        return overlapDropArea;
    },

    removeGridFill(dropBoundryEl, holdItem) {

        let columnStart = holdItem.data.grid['columnStart'],
            columnEnd = holdItem.data.grid['columnEnd'],
            rowStart = holdItem.data.grid['rowStart'],
            rowEnd = holdItem.data.grid['rowEnd'];

        for(let columnCount = columnStart, columnEndCount = columnEnd; columnCount < columnEndCount; columnCount++) {

            for(let rowCount = rowStart, rowEndCount = rowEnd; rowCount < rowEndCount; rowCount++) {
                dropBoundryEl.data.grid[columnCount][rowCount].fill = false;
                dropBoundryEl.data.grid[columnCount][rowCount].fillItem = null;
            }

        }

        return {
            dropBoundryEl: dropBoundryEl,
            columnStart: columnStart,
            columnEnd: columnEnd,
            rowStart: rowStart,
            rowEnd: rowEnd
        };
    }
    
};

export default dataManage
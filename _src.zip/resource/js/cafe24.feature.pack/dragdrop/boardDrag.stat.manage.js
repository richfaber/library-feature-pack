'use strict';

import helper from './boardDrag.helper';


/**
 * 상태변화 관리
 */
function statManage(opts) {

    this['opts'] = opts;

    this['_overlapDropArea'] = false; // 지정된 드래그 영역에 있는지
    this['_overlapItem'] = [];
    this['_overlapItemPush'] = false; // 아이템이 겹칠 경우 밀어냄,, 상세구현 해야함.

}

statManage.prototype = {
    constructor: statManage,

    /**
     * 요소에 적용된 상태 데이타 제거
     * @param {*} el
     */
    eraseStatus(el) {

        for (let prop in this['opts'].item.class) {
            el.classList.remove(this['opts'].item.class[prop]);
        }

        if (el.dataset['onDropArea'] == 'true') {

        } else {

            el.dataset['inDropArea'] = false;
            el.style.removeProperty('top');
            el.style.removeProperty('left');
            el.style.removeProperty('width');
            el.style.removeProperty('height');
            el.style.removeProperty('position');
            // el.style.position = el.orgData['position'];

        }

    },

    /**
     * 드래그 이후 아이템 복원
     * @param {*} el
     */
    fillupItem(holdItem) {

        let cloneDom = holdItem.cloneNode(true);
        cloneDom.orgData = holdItem.orgData;

        cloneDom.style.removeProperty('top');
        cloneDom.style.removeProperty('left');
        cloneDom.style.removeProperty('width');
        cloneDom.style.removeProperty('height');

        this.eraseStatus( cloneDom );
        holdItem.parentNode.insertBefore( cloneDom, holdItem );

        return cloneDom;

    },

    itemZoomIn(e, holdItem, dropArea) {

        if( holdItem.dataset['dropColumn'] ) {
            // holdItem.style.transform = `scale(${(dropArea[0].data.grid['perWidth'] * holdItem.dataset['dropColumn'])/holdItem.clientWidth})`;
            holdItem.style.width = dropArea[0].data.grid['perWidth'] * holdItem.dataset['dropColumn'] + 'px';

        }

        if( holdItem.dataset['dropRow'] ) {
            // holdItem.style.transform = `scaleY(${dropArea[0].data.grid['perHeight'] * holdItem.dataset['dropRow']/holdItem.clientHeight})`;
            holdItem.style.height = dropArea[0].data.grid['perHeight'] * holdItem.dataset['dropRow'] + 'px';
        }

    },

    /**
     * 드래그 취소, 방금전으로 이동 & dropzone 안에서 이동
     * @param {*} el
     */
    cancelItemPositionBack(holdItem) {

        if( holdItem.dataset['onDropArea'] ) {

            holdItem.style.position = 'absolute';
            holdItem.style.top = holdItem.data.overlapDropArea.data.grid[holdItem.data.grid.columnStart][holdItem.data.grid.rowStart].rowStart + 'px';
            holdItem.style.left = holdItem.data.overlapDropArea.data.grid[holdItem.data.grid.columnStart][holdItem.data.grid.rowStart].columnStart + 'px';

        } else {
            // holdItem.style.top = holdItem.t + 'px';
            // holdItem.style.left = holdItem.l + 'px';
        }

        this.eraseStatus(holdItem);

    },

    /**
     * Context Boundry 들어갈 때
     * @param {*} e
     * @param {*} el
     * @param {*} coords
     */
    hitContextBoundryDo(e, holdItem, context) {

        return new Promise((resolve, reject) => {

            let getoffContextCondition = Range.hitTest(holdItem, context);

            if (getoffContextCondition) {
                resolve({status: {'breakContextBoundry': false}, event: e});
            } else {
                reject({status: {'breakContextBoundry': true}, event: e});
            }

        });

    },

    /**
     * Drop Boundry 들어갈 때
     * @param {*} e
     * @param {*} el
     * @param {*} coords
     */
    hitDropBoundryDo(e, holdItem, context, dropBoundry) {

        return new Promise((resolve, reject) => {

            this['_overlapDropArea'] = false;

            for (let boundry of dropBoundry) {

                let getoffDropCondition = Range.hitTest(holdItem, boundry);

                if (getoffDropCondition) {
                    this['_overlapDropArea'] = boundry;
                    break;
                } else {

                    if(boundry.shadowElement) {
                        boundry.removeChild(boundry.shadowElement);
                        delete boundry.shadowElement;
                    }

                }

            }

            if (this['_overlapDropArea']) {

                holdItem.classList.add( this['opts'].item.class.overlapDropArea );
                holdItem.dataset['inDropArea'] = 'true';
                holdItem.data.overlapDropArea = this['_overlapDropArea'];
                resolve({
                    status: { 'breakDropAreaBoundry': false },
                    event: e,
                    el: holdItem,
                    overlapDropArea: this['_overlapDropArea']
                });

            } else {

                holdItem.classList.remove(this['opts'].item.class.overlapDropArea);
                holdItem.dataset['inDropArea'] = 'false';
                reject({
                    status: {'breakDropAreaBoundry': true},
                    event: e,
                    holdItem: holdItem,
                    overlapDropArea: this['_overlapDropArea']
                });

            }


        });

    },

    /**
     * 아이템 영역에서 현재 요소와 겹치는 요소 처리
     * @param e - event
     * @param el - element
     * @param compareCoords - ActionItem 에서 현재 요소를 제외한 좌표
     * @returns {Promise<any>}
     */
    hitElementDo(e, holdItem, context, overlapDropArea, compareCoords, gridCount) {

        let overlapItemInDropArea = false,
            hitStatus = false,
            gridOpt = this['opts']['dropArea']['grid'];

        this['_overlapItem'] = [];

        return new Promise((resolve, reject) => {

            if(gridCount && gridOpt && holdItem.dataset['inDropArea'] == 'true') { // 그리드 옵션이 있을 때

                loopColumn:
                for(let columnCount = gridCount.columnStart, columnEndCount = gridCount.columnStart + parseInt(holdItem.dataset['dropColumn'],10); columnCount < columnEndCount; columnCount++) {

                    loopRow:
                    for(let rowCount = gridCount.rowStart, rowEndCount = gridCount.rowStart + parseInt(holdItem.dataset['dropRow'],10); rowCount < rowEndCount; rowCount++) {

                        if(overlapDropArea.data.grid[columnCount][rowCount].fill) {

                            hitStatus = true;
                            overlapItemInDropArea = true;
                            break loopColumn;

                        }
                    }

                }

            } else {

                for (let target of compareCoords) {

                    hitStatus = Range.hitTest(holdItem, target.el);

                    if(target.el.dataset['onDropArea']) {

                        if (hitStatus) {

                            overlapItemInDropArea = true;

                        } else {

                            overlapItemInDropArea = false;

                        }
                    }

                    if (hitStatus) {

                        this['_overlapItem'].push(target.el);
                        target.el.classList.add(this['opts'].item.class.overlapItem);

                    } else {

                        target.el.classList.remove(this['opts'].item.class.overlapItem);

                    }

                }
            }

            if (this['_overlapItem'].length) {

                holdItem.classList.add(this['opts'].item.class.overlapItem);
                
            } else {

                holdItem.classList.remove(this['opts'].item.class.overlapItem);

            }

            resolve( {event: e, overlapItem: this['_overlapItem'], overlapItemInDropArea: overlapItemInDropArea} );

        });


    },

    /**
     * grid 옵션이 있을 경우
     * @param e - event
     * @param holdItem - target element
     * @param overlapDropArea - 현재 overlap 된 drop 좌표와 element
     * @returns {Promise<any>}
     */
    dropAreaInGridDo(e, holdItem, overlapDropArea) {

        let shadowElement,
            gridOpt = this['opts']['dropArea']['grid'],
            distance = {},
            gridCount,
            dropColumn = holdItem.dataset['dropColumn'],
            dropRow = holdItem.dataset['dropRow'];

        // Shadow Dom 생성
        function createShadowElement(dropAreaEl, opts) {

            if ( dropAreaEl.querySelector('.' + opts.class) ) return dropAreaEl.querySelector('.' + opts.class);

            let cloneDom = document.createElement( opts.el );
            cloneDom.className = opts.class;
            cloneDom.id = opts.id;
            cloneDom.style.position = 'absolute';

            dropAreaEl.appendChild( cloneDom, dropAreaEl );
            return cloneDom;

        }

        // Shadow Dom 위치 조정
        function calculateGridCoords(shadowElement, distance, dropColumn, dropRow) {

            let countColumn = Math.floor( distance.left / overlapDropArea.data.grid['perWidth'] ),
                countRow = Math.floor( distance.top / overlapDropArea.data.grid['perHeight'] ),
                width,
                height;

            width = dropColumn * overlapDropArea.data.grid['perWidth'];
            height = dropRow * overlapDropArea.data.grid['perHeight'];

            if(countColumn >= gridOpt.unit.widthLength - 1) countColumn = gridOpt.unit.widthLength - 1;

            shadowElement.style.left = overlapDropArea.data.grid[countColumn][countRow].columnStart + 'px';
            shadowElement.style.top = overlapDropArea.data.grid[countColumn][countRow].rowStart + 'px';
            shadowElement.style.width = width + 'px';
            shadowElement.style.height = height + 'px';

            return { columnStart: countColumn, rowStart: countRow }

        }

        return new Promise((resolve, reject) => {

            if ( this['opts'].dropArea.hasOwnProperty('grid') ) {

                distance = {
                    top: holdItem.offsetTop - (holdItem.offsetHeight/2),
                    left: holdItem.offsetLeft - overlapDropArea.getBoundingClientRect().left
                };

                if(distance.top < 0 ) distance.top = 0;
                if(distance.left < 0 ) distance.left = 0;

                shadowElement = createShadowElement( overlapDropArea, gridOpt['gridHoverElement'] );
                gridCount = calculateGridCoords( shadowElement, distance, dropColumn, dropRow );

                overlapDropArea.shadowElement = shadowElement;

            }

            resolve( { event: e, overlapDropArea: overlapDropArea, gridCount: gridCount } );

        });

    },


    /**
     * 드래그 이벤트가 끝나고 정리
     * @param el
     * @param blankDom
     * @param overlapDropArea
     * @param actionItem
     * @param gridCoord
     * @returns {Promise<any>}
     */
    arrangeAfterFinish(holdItem, actionItem, overlapDropArea, overlapItemInDropArea, gridCount, dropAllowDuplicateElement) {

        let cloneDom,
            replaceholdItem,
            statusNewItem = false,
            buttonItemDeleteElement = this['opts']['dropArea'].buttonItemDeleteElement, // @TODO: Refact target code
            deleteButton = null;

        return new Promise((resolve, reject) => {

            holdItem.classList.add(this['opts'].item.class.end);
            holdItem.classList.remove(this['opts'].item.class.move);
            holdItem.dropAreaEl = overlapDropArea;

            // grid 옵션이 있을 경우에 드래그 후에 holdItem 요소 치환. 조건문이 이상한데...
            if(overlapDropArea.shadowElement) {

                // 요소가 드래그영역 안에 있는 경우
                if(holdItem.dataset['onDropArea'] == 'true') {

                    replaceholdItem = holdItem;

                    if(overlapItemInDropArea && !dropAllowDuplicateElement) {

                    } else {

                        // console.log(gridCount);
                        holdItem.style.top = overlapDropArea.data.grid[gridCount.columnStart][gridCount.rowStart].rowStart + 'px';
                        holdItem.style.left = overlapDropArea.data.grid[gridCount.columnStart][gridCount.rowStart].columnStart + 'px';

                    }

                } else {

                    cloneDom = holdItem.cloneNode(true);
                    cloneDom.orgData = Object.extendsObject({}, holdItem.orgData);
                    cloneDom.data = Object.extendsObject({}, holdItem.data);

                    cloneDom.style.top = overlapDropArea.data.grid[gridCount.columnStart][gridCount.rowStart].rowStart + 'px';
                    cloneDom.style.left = overlapDropArea.data.grid[gridCount.columnStart][gridCount.rowStart].columnStart + 'px';
                    cloneDom.style.width = holdItem.dataset['dropColumn'] * overlapDropArea.data.grid['perWidth'] + 'px';
                    cloneDom.style.height = holdItem.dataset['dropRow'] * overlapDropArea.data.grid['perHeight'] + 'px';
                    cloneDom.dataset['onDropArea'] = true;
                    cloneDom.dropAreaEl = overlapDropArea;

                    if(buttonItemDeleteElement) {
                        deleteButton = document.createElement(buttonItemDeleteElement.el);
                        deleteButton.type = buttonItemDeleteElement.type;
                        deleteButton.className = buttonItemDeleteElement.class;
                        deleteButton.innerHTML = buttonItemDeleteElement.innerHTML;

                        cloneDom.appendChild(deleteButton);
                    }

                    replaceholdItem = cloneDom;

                    actionItem = actionItem.filter( item => item !== holdItem );
                    actionItem.push(cloneDom);

                    overlapDropArea.appendChild(cloneDom);

                    holdItem.parentNode.removeChild( holdItem );
                    statusNewItem = true;

                }

                // 마지막 좌표를 기록
                replaceholdItem.data.grid = {
                    rowStart: gridCount.rowStart,
                    rowEnd: gridCount.rowStart + parseInt(holdItem.dataset['dropRow'],10),
                    columnStart: gridCount.columnStart,
                    columnEnd: gridCount.columnStart + parseInt(holdItem.dataset['dropColumn'],10)
                };

                overlapDropArea.removeChild(overlapDropArea.shadowElement);
                delete overlapDropArea.shadowElement;

            }

            resolve( {
                holdItem: replaceholdItem,
                statusNewItem: statusNewItem,
                actionItem: actionItem,
                deleteButton: deleteButton,
                overlapDropArea: overlapDropArea,
                gridFillRange: {
                    columnStart: gridCount.columnStart,
                    columnEnd: gridCount.columnStart + parseInt(holdItem.dataset['dropColumn'],10),
                    rowStart: gridCount.rowStart,
                    rowEnd: gridCount.rowStart + parseInt(holdItem.dataset['dropRow'],10)
                }
            } );
        });

    },

    getOverlapItem: () => this['_overlapItem'],

};

export default statManage

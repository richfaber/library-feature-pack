'use strict';

import { information } from '../../../../../information';
import cfp from '../../cafe24.feature.pack.v1.0';

function addClass(className) {

    if(!this['_dom'].length) return this;

    for(let el of this['_dom']) {
        el.classList.add(className);
    }

    return this;

}

export default addClass;